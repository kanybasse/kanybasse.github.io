#include <stdio.h>
#include <stdlib.h>

// Fonction pour insérer un élément dans une liste triée
void ajouter_element(int *liste, int *taille, int valeur) {
    int i = *taille - 1;

    // Je trouve la position d'insertion en parcourant la liste de la fin vers le début
    while (i >= 0 && liste[i] > valeur) {
        liste[i + 1] = liste[i]; // Je décale les éléments vers la droite pour faire de la place
        i--;
    }
    liste[i + 1] = valeur; // J'insère le nouvel élément à la position correcte
    (*taille)++; // J'incrémente la taille de la liste
}

// Fonction pour la recherche dichotomique dans une liste triée
int recherche_dichotomique(int *liste, int taille, int valeur) {
    int debut = 0;
    int fin = taille;

    // Je continue de chercher tant que la portion de la liste à examiner n'est pas vide
    while (fin - debut > 0) {
        int milieu = (debut + fin) / 2; // Je calcule l'indice du milieu
        if (liste[milieu] < valeur) { // Si l'élément du milieu est plus petit que la valeur recherchée
            debut = milieu + 1; // Je cherche dans la moitié droite
        } else if (liste[milieu] > valeur) { // Si l'élément du milieu est plus grand que la valeur recherchée
            fin = milieu; // Je cherche dans la moitié gauche
        } else {
            return milieu; // J'ai trouvé la valeur, je retourne l'indice
        }
    }

    // Après la boucle, je vérifie si l'élément à l'indice début est la valeur recherchée
    if (debut < taille && liste[debut] == valeur) {
        return debut; // Je retourne l'indice si la valeur est trouvée
    }
    return -1; // Je retourne -1 si la valeur n'est pas trouvée
}

// Fonction pour afficher la liste
void afficher_liste(int *liste, int taille) {
    printf("[");
    for (int i = 0; i < taille; i++) {
        if (i > 0) {
            printf(", "); // J'ajoute une virgule entre les éléments
        }
        printf("%d", liste[i]); // J'affiche l'élément courant
    }
    printf("]\n"); // Je ferme la liste avec un crochet et une nouvelle ligne
}

int main() {
    int liste[1000]; // Je crée un tableau pour stocker jusqu'à 1000 éléments
    int taille = 0; // La taille initiale de la liste est 0
    char commande;
    int valeur;

    while (1) {
        printf(">>> ");
        scanf(" %c", &commande); // Je lis la commande
        if (commande == '+') {
            // Si la commande est '+', j'ajoute un élément
            scanf("%d", &valeur);
            ajouter_element(liste, &taille, valeur);
        } else if (commande == '=') {
            // Si la commande est '=', je recherche un élément
            scanf("%d", &valeur);
            int index = recherche_dichotomique(liste, taille, valeur);
            if (index >= 0) {
                printf("%d existe dans la liste.\n", valeur); // J'affiche que l'élément existe
            } else {
                printf("%d non trouvé dans la liste.\n", valeur); // J'affiche que l'élément n'existe pas
            }
        } else if (commande == '.') {
            // Si la commande est '.', j'affiche la liste
            afficher_liste(liste, taille);
        } else if (commande == 'q') {
            // Si la commande est 'q', je quitte le programme
            break;
        }
    }

    return 0;
}
