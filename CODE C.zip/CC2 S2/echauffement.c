#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_LEN 1000

// Fonction pour compter les occurrences des lettres dans le texte
void compter_occurrences(char *texte) {
    int occurrences[26] = {0}; // Je crée un tableau pour stocker les occurrences des lettres de 'a' à 'z'
    int len = strlen(texte);   // Je trouve la longueur du texte

    // Je parcours chaque caractère du texte
    for (int i = 0; i < len; i++) {
        char ch = tolower(texte[i]); // Je convertis le caractère en minuscule
        if (isalpha(ch)) {           // Je vérifie si le caractère est une lettre alphabétique
            occurrences[ch - 'a']++; // J'incrémente le compteur correspondant à la lettre
        }
    }

    // J'affiche le texte original
    printf("Texte : \"%s\"\n", texte);

    // J'affiche les occurrences des lettres en ordre alphabétique
    for (int i = 0; i < 26; i++) {
        if (occurrences[i] > 0) { // Si la lettre est présente
            printf("'%c' : %d\n", i + 'a', occurrences[i]); // J'affiche la lettre et son compte
        }
    }
}

int main() {
    char texte[MAX_LEN]; // Je crée un tableau pour stocker le texte

    // Je lis la chaîne de caractères entrée par l'utilisateur
    printf("Entrez du texte : ");
    fgets(texte, MAX_LEN, stdin);

    // J'enlève le caractère de nouvelle ligne à la fin de la chaîne
    texte[strcspn(texte, "\n")] = 0;

    // J'appelle la fonction pour compter les occurrences
    compter_occurrences(texte);

    return 0;
}
