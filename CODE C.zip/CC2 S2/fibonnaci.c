#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* Je déclare les fonctions que je vais utiliser plus tard */
unsigned long fibo_rec(int n); // Cette fonction calcule Fibonacci de manière récursive
unsigned long fibo_lin(int n); // Cette fonction calcule Fibonacci de manière itérative
void matrix2x2_set(unsigned long matrix[2][2], unsigned long a, unsigned long b,
                   unsigned long c, unsigned long d); // Cette fonction affecte des valeurs à une matrice 2x2
void vector2_set(unsigned long vector[2], unsigned long a, unsigned long b); // Cette fonction affecte des valeurs à un vecteur 2
void matrix2x2_mul_vector2(unsigned long res[2], unsigned long first[2][2], unsigned long second[2]); // Cette fonction multiplie une matrice par un vecteur
void matrix2x2_copy(unsigned long dest[2][2], unsigned long src[2][2]); // Cette fonction copie une matrice
void matrix2x2_mul_matrix2x2(unsigned long res[2][2], unsigned long first[2][2], unsigned long second[2][2]); // Cette fonction multiplie deux matrices 2x2
void matrix2x2_display(unsigned long matrix[2][2]); // Cette fonction affiche une matrice
void matrix2x2_power_naive(unsigned long res[2][2], unsigned long matrix[2][2], int n); // Cette fonction calcule la puissance d'une matrice de manière naïve
void matrix2x2_power_fast(unsigned long res[2][2], unsigned long matrix[2][2], int n); // Cette fonction calcule la puissance d'une matrice de manière rapide
unsigned long fibo_matrix(int n); // Cette fonction calcule Fibonacci à l'aide d'une matrice 2x2
int main(); // Cette fonction est la fonction principale

/* Je définis la fonction récursive pour calculer Fibonacci */
unsigned long fibo_rec(int n) {
    if (n <= 1) {
        return n; // Cas de base
    }
    return fibo_rec(n - 1) + fibo_rec(n - 2); // Appels récursifs
}

/* Je définis la fonction itérative pour calculer Fibonacci */
unsigned long fibo_lin(int n) {
    unsigned long u0 = 0, u1 = 1, r;
    while (n-- > 0) {
        r = u1;
        u1 = u1 + u0;
        u0 = r;
    }
    return u0;
}

/* Je définis la fonction pour affecter une matrice 2x2 */
void matrix2x2_set(unsigned long matrix[2][2], unsigned long a, unsigned long b,
                   unsigned long c, unsigned long d) {
    matrix[0][0] = a; matrix[0][1] = b;
    matrix[1][0] = c; matrix[1][1] = d;
}

/* Je définis la fonction pour affecter un vecteur 2 */
void vector2_set(unsigned long vector[2], unsigned long a, unsigned long b) {
    vector[0] = a;
    vector[1] = b;
}

/* Je définis la fonction pour multiplier une matrice par un vecteur */
void matrix2x2_mul_vector2(unsigned long res[2], unsigned long first[2][2], unsigned long second[2]) {
    unsigned long x = second[0], y = second[1];
    res[0] = first[0][0] * x + first[0][1] * y;
    res[1] = first[1][0] * x + first[1][1] * y;
}

/* Je définis la fonction pour copier une matrice */
void matrix2x2_copy(unsigned long dest[2][2], unsigned long src[2][2]) {
    int i, j;
    for (i = 0; i < 2; ++i) {
        for (j = 0; j < 2; ++j) {
            dest[i][j] = src[i][j];
        }
    }
}

/* Je définis la fonction pour multiplier deux matrices 2x2 */
void matrix2x2_mul_matrix2x2(unsigned long res[2][2], unsigned long first[2][2], unsigned long second[2][2]) {
    unsigned long a = first[0][0], b = first[0][1];
    unsigned long c = first[1][0], d = first[1][1];
    unsigned long x = second[0][0], z = second[0][1];
    unsigned long y = second[1][0], w = second[1][1];
    res[0][0] = a * x + b * y;
    res[0][1] = a * z + b * w;
    res[1][0] = c * x + d * y;
    res[1][1] = c * z + d * w;
}

/* Je définis la fonction pour afficher une matrice */
void matrix2x2_display(unsigned long matrix[2][2]) {
    printf("Matrix2x2 :\n");
    int i, j;
    for (i = 0; i < 2; ++i) {
        if (i != 0) {
            printf("\n");
        }
        for (j = 0; j < 2; ++j) {
            if (j != 0) {
                printf(" ");
            }
            printf("%18lu", matrix[i][j]);
        }
    }
}

/* Je définis la fonction pour calculer la puissance d'une matrice (méthode naïve) */
void matrix2x2_power_naive(unsigned long res[2][2], unsigned long matrix[2][2], int n) {
    unsigned long tmp[2][2];
    /* Initialisation de la matrice temporaire à l'identité */
    matrix2x2_set(tmp, 1, 0, 0, 1);
    while (n-- > 0) {
        /* Multiplication de la matrice temporaire par la matrice donnée */
        matrix2x2_mul_matrix2x2(tmp, tmp, matrix);
    }
    /* Copie du résultat dans la matrice de résultat */
    matrix2x2_copy(res, tmp);
}

/* Je définis la fonction pour calculer la puissance rapide d'une matrice */
void matrix2x2_power_fast(unsigned long res[2][2], unsigned long matrix[2][2], int n) {
    unsigned long tmp[2][2];
    unsigned long val[2][2];
    /* J'initialise la matrice temporaire à l'identité */
    matrix2x2_set(tmp, 1, 0, 0, 1);
    /* Je copie la matrice donnée dans une autre matrice */
    matrix2x2_copy(val, matrix);
    while (n > 0) {
        if (n % 2 == 1) {
            /* Si n est impair, je multiplie la matrice temporaire par la matrice */
            matrix2x2_mul_matrix2x2(tmp, tmp, val);
        }
        /* Je multiplie la matrice par elle-même pour réduire n de moitié à chaque itération */
        matrix2x2_mul_matrix2x2(val, val, val);
        n /= 2;
    }
    /* Je copie le résultat dans la matrice de résultat */
    matrix2x2_copy(res, tmp);
}

/* Je définis la fonction pour calculer Fibonacci à l'aide d'une matrice 2x2 */
unsigned long fibo_matrix(int n) {
    unsigned long matrix[2][2];
    unsigned long vector[2];
    /* J'affecte les valeurs de la matrice de Fibonacci */
    matrix2x2_set(matrix, 1, 1, 1, 0);
    /* J'affecte les valeurs du vecteur initial */
    vector2_set(vector, 1, 0);
    /* Je calcule la puissance de la matrice */
    matrix2x2_power_fast(matrix, matrix, n);
    /* Je multiplie la matrice par le vecteur */
    matrix2x2_mul_vector2(vector, matrix, vector);
    /* Je retourne la valeur de Fibonacci */
    return vector[1];
}

/* Je définis la fonction principale */
int main() {
    int n;
    /* Je demande à l'utilisateur de saisir la valeur de l'indice à calculer */
    printf("Entrez la valeur de l'indice à calculer : ");
    scanf("%d", &n);
    unsigned long res;
    clock_t start, end;
    /* Je commence le chronométrage */
    start = clock();
    /* J'utilise la méthode de la matrice pour calculer Fibonacci */
    res = fibo_matrix(n);
    /* Je termine le chronométrage */
    end = clock();
    /* J'affiche le résultat avec le temps écoulé */
    printf("fibo_matrix(%d) = %lu (%g s)\n", n, res, (double)(end - start) / CLOCKS_PER_SEC);
    /* Je recommence le chronométrage pour la méthode itérative */
    start = clock();
    /* J'utilise la méthode itérative pour calculer Fibonacci */
    res = fibo_lin(n);
    /* Je termine le chronométrage */
    end = clock();
    /* J'affiche le résultat avec le temps écoulé */
    printf("fibo_lin(%d) = %lu (%g s)\n", n, res, (double)(end - start) / CLOCKS_PER_SEC);
    /* Si n est petit, je calcule Fibonacci avec la méthode récursive */
    if (n <= 50) {
        /* Je recommence le chronométrage */
        start = clock();
        /* J'utilise la méthode récursive pour calculer Fibonacci */
        res = fibo_rec(n);
        /* Je termine le chronométrage */
        end = clock();
        /* J'affiche le résultat avec le temps écoulé */
        printf("fibo_rec(%d) = %lu (%g s)\n", n, res, (double)(end - start) / CLOCKS_PER_SEC);
    } else {
        /* Si n est trop grand, j'indique que le calcul prendrait trop de temps */
        printf("fibo_rec(%d) = ? (trop long)\n", n);
    }
    /* Je quitte le programme avec un succès */
    exit(EXIT_SUCCESS);
}
