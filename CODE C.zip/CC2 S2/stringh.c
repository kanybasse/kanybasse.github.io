#include <stdio.h>
#include <stdlib.h>

/* Fonction pour calculer la longueur d'une chaîne de caractères */
int esgi_strlen(const char texte[]) {
    int i;
    /* Je parcours la chaîne de caractères jusqu'au marqueur de fin */
    for (i = 0; texte[i] != '\0'; ++i) {}
    return i;
}

/* Fonction pour copier une chaîne de caractères dans une autre */
void esgi_strcpy(char destination[], const char source[]) {
    int i;
    /* Je copie individuellement les caractères jusqu'à atteindre le marqueur de fin */
    for (i = 0; source[i] != '\0'; ++i) {
        destination[i] = source[i];
    }
    /* J'ajoute le marqueur de fin à la fin de la chaîne */
    destination[i] = '\0';
}

/* Fonction pour concaténer deux chaînes de caractères */
void esgi_strcat(char destination[], const char source[]) {
    int i;
    /* Je recherche la position du marqueur de fin de la chaîne destination */
    int offset = esgi_strlen(destination);
    /* Je copie les caractères de la chaîne source relativement à la fin de destination */
    for (i = 0; source[i] != '\0'; ++i) {
        destination[i + offset] = source[i];
    }
    /* J'ajoute le marqueur de fin à la fin de la chaîne résultante */
    destination[i + offset] = '\0';
}

/* Fonction pour comparer deux chaînes de caractères */
int esgi_strcmp(const char first[], const char second[]) {
    int i;
    /* Je compare les caractères des deux chaînes jusqu'à ce qu'un marqueur de fin soit atteint dans l'une d'elles */
    for (i = 0; first[i] != '\0' && second[i] != '\0'; ++i) {
        /* Si les caractères sont différents, je détermine leur ordre lexicographique */
        if (first[i] < second[i]) {
            return -1;
        } else if (first[i] > second[i]) {
            return 1;
        }
        /* Si les caractères sont identiques, je passe au suivant */
    }
    /* Si une chaîne est un préfixe de l'autre, je retourne leur différence de longueur */
    if (first[i] < second[i]) {
        return -1;
    } else if (first[i] > second[i]) {
        return 1;
    } else {
        return 0; // Les chaînes sont identiques
    }
}

/* Fonction principale */
int main() {
    char texte[] = "Welcome to ESGI!";
    char hello[] = "Hello";
    char copie[50];

    /* J'affiche la longueur du texte */
    printf("esgi_strlen(\"%s\") = %d\n", texte, esgi_strlen(texte));

    /* Je copie une chaîne dans une autre */
    esgi_strcpy(copie, "Eleve, ");
    printf("copie = \"%s\"\n", copie);

    /* Je concatène deux chaînes */
    esgi_strcat(copie, texte);
    printf("copie = \"%s\"\n", copie);

    /* Je compare deux chaînes */
    printf("esgi_strcmp(\"Hello\", \"Hello\") = %d = 0\n", esgi_strcmp(hello, "Hello"));
    printf("esgi_strcmp(\"Hello\", \"Bonjour\") = %d > 0\n", esgi_strcmp(hello, "Bonjour"));
    printf("esgi_strcmp(\"Hello\", \"Hell\") = %d > 0\n", esgi_strcmp(hello, "Hell"));
    printf("esgi_strcmp(\"Bonjour\", \"Hello\") = %d < 0\n", esgi_strcmp("Bonjour", hello));

    exit(EXIT_SUCCESS);
}
