#include <stdio.h>
#include <stdlib.h>

#define TAILLE 10

/* Fonction min_index: Je cherche l'indice du plus petit élément dans le tableau values */
int min_index(int values[], int taille) {
    int index = 0; // J'initialise l'indice du plus petit élément au premier élément
    int i;
    for (i = 1; i < taille; ++i) { // Je parcours le tableau à partir du deuxième élément
        if (values[i] < values[index]) { // Si je trouve un élément plus petit, j'actualise l'indice
            index = i;
        }
    }
    return index; // Je retourne l'indice du plus petit élément
}

/* Fonction min_value: Je retourne la valeur du plus petit élément dans le tableau values */
int min_value(int values[], int taille) {
    return values[min_index(values, taille)]; // J'utilise la fonction min_index pour obtenir l'indice du plus petit élément
}

/* Fonction max_index: Je cherche l'indice du plus grand élément dans le tableau values */
int max_index(int values[], int taille) {
    int index = 0; // J'initialise l'indice du plus grand élément au premier élément
    int i;
    for (i = 1; i < taille; ++i) { // Je parcours le tableau à partir du deuxième élément
        if (values[i] > values[index]) { // Si je trouve un élément plus grand, j'actualise l'indice
            index = i;
        }
    }
    return index; // Je retourne l'indice du plus grand élément
}

/* Fonction max_value: Je retourne la valeur du plus grand élément dans le tableau values */
int max_value(int values[], int taille) {
    return values[max_index(values, taille)]; // J'utilise la fonction max_index pour obtenir l'indice du plus grand élément
}

/* Fonction moyenne: Je calcule la moyenne des éléments dans le tableau values */
float moyenne(int values[], int taille) {
    long somme = 0; // J'initialise la somme à zéro
    int i;
    for (i = 0; i < taille; ++i) { // Je parcours le tableau et j'additionne tous les éléments
        somme += values[i];
    }
    return (float)somme / taille; // Je retourne la moyenne en divisant la somme par le nombre d'éléments
}

/* Fonction principale */
int main() {
    int valeurs[TAILLE] = {5, 9, 1, 4, 8, 3, 0, 6, 2, 7}; // Je déclare un tableau de valeurs

    // J'affiche le minimum, son indice, le maximum, son indice, et la moyenne
    printf("minimum : valeurs[%d] = %d\n", min_index(valeurs, TAILLE), min_value(valeurs, TAILLE));
    printf("maximum : valeurs[%d] = %d\n", max_index(valeurs, TAILLE), max_value(valeurs, TAILLE));
    printf("moyenne : %g\n", moyenne(valeurs, TAILLE));

    exit(EXIT_SUCCESS); 
