#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Fonction pour coder ou décoder un texte avec la méthode de Vigenère */
void vigenere(char texte[], char cle[], int sign, char message[]) {
    int i, j;
    int value;
    int offset;
    
    /* Je parcours chaque caractère du texte */
    for (i = 0, j = 0; texte[i] != '\0'; ++i) {
        /* Je détermine la position dans l'alphabet */
        if (texte[i] >= 'A' && texte[i] <= 'Z') {
            value = texte[i] - 'A';
            message[i] = 'A'; // Je maintiens la casse
        } else if (texte[i] >= 'a' && texte[i] <= 'z') {
            value = texte[i] - 'a';
            message[i] = 'a'; // Je maintiens la casse
        } else {
            /* Si ce n'est pas une lettre, je ne fais pas de traitement */
            message[i] = texte[i];
            continue;
        }
        
        /* Je récupère le décalage de la clé */
        if (cle[j] >= 'A' && cle[j] <= 'Z') {
            offset = cle[j] - 'A';
        } else if (cle[j] >= 'a' && cle[j] <= 'z') {
            offset = cle[j] - 'a';
        }
        
        /* Je calcule la position décalée de la lettre dans l'alphabet depuis la clé */
        value = ((value + sign * offset) % 26 + 26) % 26;
        message[i] += value;
        
        /* J'avance dans la clé */
        j = (j + 1) % strlen(cle);
    }
    message[i] = '\0'; // Je termine la chaîne de caractères
}

/* Fonction pour lire un texte depuis l'entrée */
void lire_texte(char texte[]) {
    int c;
    int i;
    
    /* Je lis chaque caractère de l'entrée jusqu'à rencontrer un retour à la ligne ou la fin de fichier */
    c = getchar();
    for (i = 0; c != '\n' && c != EOF; ++i) {
        texte[i] = c;
        c = getchar();
    }
    texte[i] = '\0'; // Je termine la chaîne de caractères
}

/* Fonction principale */
int main() {
    char cle[50];
    char choix;
    char texte[500];
    char message[500];

    /* Je demande à l'utilisateur d'entrer une clé */
    printf("Entrez une clé : ");
    scanf("%s", cle);

    do {
        /* Je demande à l'utilisateur ce qu'il souhaite faire */
        printf("Que voulez-vous faire ?\nc - coder\nd - decoder\nq - quitter\nvotre choix : ");
        scanf(" %c ", &choix);

        switch (choix) {
            case 'c':
                /* Je demande à l'utilisateur d'entrer un message à coder */
                printf("Entrez un message : ");
                lire_texte(texte);
                printf("texte = \"%s\"\n", texte);
                vigenere(texte, cle, 1, message);
                printf("codage_vigenere(K = \"%s\", M = \"%s\") =\n\"%s\"\n", cle, texte, message);
                break;
            case 'd':
                /* Je demande à l'utilisateur d'entrer un message à décoder */
                printf("Entrez un message : ");
                lire_texte(texte);
                vigenere(texte, cle, -1, message);
                printf("decodage_vigenere(K = \"%s\", M = \"%s\") =\n\"%s\"\n", cle, texte, message);
                break;
        }
    } while (choix != 'q'); // Je répète jusqu'à ce que l'utilisateur choisisse de quitter

    exit(EXIT_SUCCESS);
}
