#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <SDL/SDL.h>

#define MAX_ENTRIES 20

/* Je parametre la fenêtre */
const int largeur = 800; // Largeur de la fenêtre
const int hauteur = 600; // Hauteur de la fenêtre
const char *titre = "ESGI random"; // Titre de la fenêtre
SDL_Surface *ecran = NULL; // Surface de l'écran
const int trials = 10000000; // Nombre d'essais
int essai = 0; // Compteur d'essais
unsigned long counts[MAX_ENTRIES]; // Tableau pour compter les occurrences

/* je mets les fonction pour dessiner les résultats des générateurs de nombres aléatoires */
void draw_random() {
    char buffer[1024];
    int i;
    unsigned long max_count = 0;
    unsigned long sum_count = 0;
    for (i = 0; i < MAX_ENTRIES; ++i) {
        if (counts[i] > max_count) max_count = counts[i];
        sum_count += counts[i];
    }
    for (i = 0; i < MAX_ENTRIES; ++i) {
        // ici je dessine les rectangles pour les comptes
        boxRGBA(ecran,
                300, 100 + (i * (hauteur - 200)) / (MAX_ENTRIES + 1),
                300 + ((largeur - 400) * (counts[i])) / max_count,
                100 + ((i + 1) * (hauteur - 200)) / (MAX_ENTRIES + 1),
                127, 127, 127, 255);
        rectangleRGBA(ecran,
                      300, 100 + (i * (hauteur - 200)) / (MAX_ENTRIES + 1),
                      300 + ((largeur - 400) * (counts[i])) / max_count,
                      100 + ((i + 1) * (hauteur - 200)) / (MAX_ENTRIES + 1),
                      255, 255, 255, 255);
        sprintf(buffer, "P(X = %d) = %g", i, (double)counts[i] / sum_count);
        stringRGBA(ecran, 10, 100 + ((i + 0.5) * (hauteur - 200)) / (MAX_ENTRIES + 1), buffer, 255, 255, 255, 255);
    }
    sprintf(buffer, "%d / %d essais", essai, trials);
    stringRGBA(ecran, 10, 10, buffer, 255, 255, 255, 255);
}

/* Générateur de nombres aléatoires uniformes */
int uniform_random(int entries) {
    return rand() % entries;
}

/* Générateur de nombres aléatoires avec biais */
int biased_fair_take_random(int entries) {
    int i;
    for (i = 0; i < entries; ++i) {
        if (rand() % entries == 0) return i;
    }
    return entries - 1;
}

/* Générateur de nombres aléatoires avec répartition triangulaire uniforme */
int triangular_random(int entries) {
    int r = rand() % (RAND_MAX * 2 + 1);
    return r < RAND_MAX ? r / (RAND_MAX / entries) : (RAND_MAX * 2 - r) / (RAND_MAX / entries);
}

/* Générateur de nombres aléatoires avec répartition exponentielle */
double exponential_random(double lambda) {
    double u = -log(1 - rand() / (double)RAND_MAX) / lambda;
    return u;
}

/* Générateur de nombres aléatoires avec répartition normale */
double normal_random(double mean, double stddev) {
    double u, v, x, y;
    static double saved_u = -1, saved_v = -1;
    static int have_saved_value = 0;

    if (have_saved_value) {
        u = saved_u;
        have_saved_value = 0;
    } else {
        do {
            u = 2 * rand() / (double)RAND_MAX - 1;
            v = 2 * rand() / (double)RAND_MAX - 1;
            x = u * u + v * v;
        } while (x >= 1 || x == 0);
        y = sqrt(-2 * log(x) / x);
        u *= y;
        v *= y;
        saved_u = v;
        have_saved_value = 1;
    }
    return mean + stddev * u;
}

/* Générateur de nombres aléatoires avec répartition gamma */
double gamma_random(double alpha, double beta) {
    double d, c, x, u, v, z;
    static double saved_u = -1, saved_v = -1;
    static int have_saved_value = 0;

    if (alpha < 1) {
        d = alpha + 1;
        c = 1 / sqrt(2 * d);
        while (1) {
            do {
                u = 2 * rand() / (double)RAND_MAX - 1;
                v = 2 * rand() / (double)RAND_MAX - 1;
                x = u * u + v * v;
            } while (x >= 1 || x == 0);
            z = u * sqrt(-2 * log(x) / x);
            y = d * v * sqrt(-2 * log(x) / x);
            if (y <= (alpha - 1) * log(d) - d + 1 || log(y) + d - 1 <= (alpha - 1) * log(d)) {
                return c * z;
            }
        }
    } else {
        if (have_saved_value) {
            u = saved_u;
            v = saved_v;
            have_saved_value = 0;
        } else {
            do {
                u = 2 * rand() / (double)RAND_MAX - 1;
                v = 2 * rand() / (double)RAND_MAX - 1;
                x = u * u + v * v;
            } while (x >= 1 || x == 0);
            z = u * sqrt(-2 * log(x) / x);
            y = v * sqrt(-2 * log(x) / x);
            saved_u = y;
            have_saved_value = 1;
        }
        d = alpha - 1;
        c = 1 / sqrt(2 * d);
        return c * (z + d * (1 - 2 * (v < 0)));
    }
}

/* Fonction pour tester les générateurs de nombres aléatoires */
void test_random(int entries, int (*random)(int)) {
    char buffer[1024];
    int i;
    for (i = 0; i < MAX_ENTRIES; ++i) {
        counts[i] = 0; // Réinitialiser les comptes
    }
    unsigned long t = 1;
    int updates = 0;
    for (essai = 0; essai < trials; ++essai) {
        ++(counts[random(entries)]);
        if (essai > t || essai % 10000 == 0) {
            SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 51, 51, 51)); // Remplir l'écran avec une couleur
            draw_random(); // Dessiner les résultats
            SDL_Flip(ecran); // Mettre à jour l'écran
            if (essai > t) {
                t *= 2;
                SDL_Delay(1 + 1000 / (++updates)); // Attendre un peu
            }
        }
    }
}

/* Fonction pour lire la commande de l'utilisateur */
int read_command() {
    printf("Aléatoires :\n");
    printf(" 1. uniform random\n");
    printf(" 2. biased fair take random\n");
    printf(" 3. triangular random\n");
    printf(" 4. exponential random\n");
    printf(" 5. normal random\n");
    printf(" 6. gamma random\n");
    printf(" 0. Quitter\n");
    printf("Entrez votre choix : ");
    int choice;
    scanf("%d", &choice); // Lire le choix de l'utilisateur
    return choice;
}

/* Fonction principale */
int main(int argc, char *argv[]) {
    SDL_Init(SDL_INIT_VIDEO); // Initialiser SDL
    ecran = SDL_SetVideoMode(largeur, hauteur, 32, SDL_HWSURFACE | SDL_DOUBLEBUF); // Créer la fenêtre
    SDL_WM_SetCaption(titre, NULL); // Définir le titre de la fenêtre
    srand(time(NULL)); // Initialiser le générateur de nombres aléatoires
    int choice;
    while ((choice = read_command()) != 0) {
        switch (choice) {
            case 1:
                test_random(MAX_ENTRIES, uniform_random); // Tester les nombres aléatoires uniformes
                break;
            case 2:
                test_random(MAX_ENTRIES, biased_fair_take_random); // Tester les nombres aléatoires biaisés
                break;
            case 3:
                test_random(MAX_ENTRIES, triangular_random); // Tester les nombres aléatoires triangulaires
                break;
            case 4:
                test_random(MAX_ENTRIES, exponential_random); // Tester les nombres aléatoires exponentiels
                break;
            case 5:
                test_random(MAX_ENTRIES, normal_random); // Tester les nombres aléatoires normaux
                break;
            case 6:
                test_random(MAX_ENTRIES, gamma_random); // Tester les nombres aléatoires gamma
                break;
            default:
                printf("Choix invalide\n"); // Choix invalide
                break;
        }
    }
    SDL_Quit(); // Quitter SDL
    return 0; // Terminer le programme
}
