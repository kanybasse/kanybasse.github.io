#include <stdio.h>
#include <math.h>
#include <time.h>

// J'implémente ici la fonction de recherche dichotomique.
double dichotomie(double debut, double fin, double (*fonction)(double, double), double alpha, int maxIterations, double epsilon) {
    double solution;
    // Je boucle pour un nombre maximal d'itérations.
    for (int i = 0; i < maxIterations; i++) {
        // Je calcule le point milieu de l'intervalle.
        solution = (debut + fin) / 2;
        // Je vérifie si le produit des valeurs aux extrémités et au milieu est négatif pour ajuster l'intervalle.
        if (fonction(solution, alpha) * fonction(debut, alpha) < 0) {
            fin = solution;
        } else if (fonction(solution, alpha) * fonction(fin, alpha) < 0) {
            debut = solution;
        } else {
            // Si la solution est trouvée (fonction(solution) = 0), je sors de la boucle.
            break;
        }
    }

    // Je vérifie si l'intervalle a convergé à une précision acceptable.
    if (fabs(debut - fin) > epsilon) {
        fprintf(stderr, "L'algorithme n'a pas convergé\n");
    }

    // Je retourne la solution trouvée.
    return solution;
}

// Je définis la fonction à résoudre : f(x) = x^2 - |alpha|.
double f(double x, double alpha) {
    return x * x - fabs(alpha);
}

// Je calcule la racine carrée de alpha en utilisant la recherche dichotomique.
double racine_carre(double alpha, int maxIterations) {
    return dichotomie(0, alpha, f, alpha, maxIterations, 1e-15);
}

// Je compare les résultats de la recherche dichotomique et de la fonction sqrt.
void comparaison_racine_carre(double alpha) {
    clock_t start_time, end_time;
    double result_dichotomie, result_cmath;
    double time_dichotomie, time_cmath;

    // Je mesure le temps pour la méthode de dichotomie.
    start_time = clock();
    result_dichotomie = racine_carre(alpha, 100);
    end_time = clock();
    time_dichotomie = ((double) (end_time - start_time)) / CLOCKS_PER_SEC;

    // Je mesure le temps pour la méthode native de sqrt.
    start_time = clock();
    result_cmath = sqrt(alpha);
    end_time = clock();
    time_cmath = ((double) (end_time - start_time)) / CLOCKS_PER_SEC;

    // J'affiche les résultats et le temps d'exécution pour chaque méthode.
    printf("Pour α = %g:\n", alpha);
    printf("La racine carrée avec dichotomie est %.17f (en %f s)\n", result_dichotomie, time_dichotomie);
    printf("La racine carrée avec sqrt est %.17f (en %f s)\n\n", result_cmath, time_cmath);
}

// Fonction principale où je demande à l'utilisateur d'entrer un réel.
int main() {
    double alpha;

    // Je demande à l'utilisateur d'entrer un réel.
    printf("Entrez un réel : ");
    scanf("%lf", &alpha);

    // Je compare les résultats pour la valeur entrée.
    comparaison_racine_carre(alpha);

    return 0;
}
