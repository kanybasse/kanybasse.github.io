#include <stdio.h>
#include <stdlib.h>

/* Fonction pour lire un entier en évitant les erreurs */
int scanInt() {
    int res = 0;
    while(scanf("%d", &res) != 1) {
        printf("\n[Info] : Un entier sur %lu octets est attendu.\n", sizeof(int));
        while(getchar() != '\n'); // Consomme la ligne actuelle
    }
    return res;
}

/* Fonction pour vérifier si un caractère est un opérateur valide */
int carIsOp(char op) {
    return (op == '+' || op == '-' || op == '/' || op == '*' || op == '%' || op == '^');
}

/* Fonction pour lire un opérateur valide */
char scanOp() {
    char res = 0;
    int valid = 0;
    do {
        scanf(" %c", &res);
        valid = carIsOp(res);
        if (!valid) {
            printf("\n[Info] : Opérateur incorrect. Attendu +, -, *, /, %% ou ^.\n");
        }
    } while (!valid);
    return res;
}

/* Opérations */

long addInt(int first, int second) {
    return (long)first + second;
}

long subInt(int first, int second) {
    return (long)first - second;
}

long mulInt(int first, int second) {
    return (long)first * second;
}

double divInt(int first, int second) {
    if (second == 0) {
        printf("\n[Info] : division par 0.\n");
    }
    return (double)first / second;
}

int modInt(int first, int second) {
    if (second == 0) {
        printf("\n[Info] : division par 0.\n");
    }
    return first % second;
}

long powInt(int first, int second) {
    if (second < 0) {
        return 0;
    }
    long res = 1;
    for (; second > 0; --second) {
        res *= first;
    }
    return res;
}

/* Fonction pour calculer et afficher le résultat de l'opération */
void compute(int first, char op, int second) {
    switch (op) {
        case '+' : {
            printf(" = %ld\n", addInt(first, second));
            break;
        }
        case '-' : {
            printf(" = %ld\n", subInt(first, second));
            break;
        }
        case '*' : {
            printf(" = %ld\n", mulInt(first, second));
            break;
        }
        case '/' : {
            printf(" = %lg\n", divInt(first, second));
            break;
        }
        case '%' : {
            printf(" = %d\n", modInt(first, second));
            break;
        }
        case '^' : {
            printf(" = %ld\n", powInt(first, second));
            break;
        }
    }
}

int main() {
    int first, second;
    char op;
    
    printf(">>> ");
    first = scanInt(); // Je saisis le premier entier
    op = scanOp(); // Je saisis l'opérateur
    second = scanInt(); // Je saisis le deuxième entier
    
    compute(first, op, second); // Je calcule et j'affiche le résultat
    
    exit(EXIT_SUCCESS);
}
