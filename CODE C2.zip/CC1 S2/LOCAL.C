#include <stdio.h>
#include <stdlib.h>

/* Fonction pour afficher le résultat de l'addition */
void afficher_addition(int first, int second) {
    int res = first + second; // Je calcule l'addition
    printf(" = %d\n", res); // J'affiche le résultat
}

/* Fonction pour afficher le résultat de la multiplication */
void afficher_multiplication(int first, int second) {
    long res = (long)first * second; // Je calcule la multiplication
    printf(" = %ld\n", res); // J'affiche le résultat
}

/* Fonction pour afficher le résultat de la division */
void afficher_division(int first, int second) {
    double res = (double)first / second; // Je calcule la division
    printf(" = %lg\n", res); // J'affiche le résultat
}

int main() {
    int first, second;
    char res;
    
    printf(">>> ");
    scanf("%d %c %d", &first, &res, &second); // Je saisis les valeurs et l'opérateur
    
    switch(res) {
        case '+' :
            afficher_addition(first, second); // J'appelle la fonction d'addition
            break;
        case '*' :
            afficher_multiplication(first, second); // J'appelle la fonction de multiplication
            break;
        case '/' :
            afficher_division(first, second); // J'appelle la fonction de division
            break;
    }
    
    exit(EXIT_SUCCESS);
}
