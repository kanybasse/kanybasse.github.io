#include <stdio.h>
#include <stdlib.h>

// Définition de la fonction menu
int menu() {
    // Déclaration de la variable choix
    int choix;
    // Boucle tant que le choix n'est pas valide
    do {
        // Affichage du menu
        printf("Menu :\n");
        printf("1 - un truc\n");
        printf("2 - un autre\n");
        printf("3 - quitter\n---\nVotre choix : ");
        // Récupération du choix de l'utilisateur
        scanf("%d", &choix);
    } while (choix < 1 || choix > 3); // Vérification de la validité du choix
    // Renvoi du choix de l'utilisateur
    return choix;
}

// Fonction principale
int main() {
    // Appel de la fonction menu et affichage du choix de l'utilisateur
    printf("%d, bien reçu.\n", menu());
    
    exit(EXIT_SUCCESS);
}
