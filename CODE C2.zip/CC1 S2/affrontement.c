#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* Statistiques générales en début d'une partie */
int max_vie = 100; // Vie maximale possible
int start_atk = 50; // Attaque de départ
int start_def = 20; // Défense de départ

/* Statistiques du joueur */
int self_vie; // Vie du joueur
int self_atk; // Attaque du joueur
int self_def; // Défense du joueur

/* Statistiques de l'adversaire */
int adv_vie; // Vie de l'adversaire
int adv_atk; // Attaque de l'adversaire
int adv_def; // Défense de l'adversaire

/* J'utilise des variables globales ici pour séparer les données en fonctions, faute de savoir comment passer plusieurs valeurs via des pointeurs ou des retours. */

/* Initialisation des statistiques des deux joueurs */
void init() {
    self_vie = max_vie;
    self_atk = start_atk;
    self_def = start_def;
    adv_vie = max_vie;
    adv_atk = start_atk;
    adv_def = start_def;
}

/* Fonction générale pour calculer les dégâts d'une attaque */
int degats(int tori_atk, int uke_def) {
    int res = tori_atk / uke_def;
    if (res < 1) {
        res = 1;
    }
    return res;
}

/* Fonction générale pour appliquer un buff : en pourcentage */
int boost(int value, int pourcentage) {
    value = ((long)(100 + pourcentage) * value) / 100;
    if (value < 1) {
        value = 1;
    }
    return value;
}

/* Actions du joueur */
void self_regen() {
    self_vie += 0.25 * max_vie; // Régénération de la vie du joueur
    if (self_vie > max_vie) {
        self_vie = max_vie;
    }
}

void self_hit() {
    adv_vie -= degats(self_atk, adv_def); // Attaque de l'adversaire
}

void self_boost_atk() {
    self_atk = boost(self_atk, 20); // Augmentation de l'attaque du joueur
}

void self_boost_def() {
    self_def = boost(self_def, 30); // Augmentation de la défense du joueur
}

void self_action(int id) {
    switch(id) {
        case 1: {
            printf("Je cogne l'adversaire.\n");
            self_hit();
            break;
        }
        case 2: {
            printf("Je me soigne.\n");
            self_regen();
            break;
        }
        case 3: {
            printf("J'augmente mon attaque.\n");
            self_boost_atk();
            break;
        }
        case 4: {
            printf("J'augmente ma défense.\n");
            self_boost_def();
            break;
        }
    }
}

/* Actions de l'adversaire */
void adv_regen() {
    adv_vie += 0.25 * max_vie; // Régénération de la vie de l'adversaire
    if (adv_vie > max_vie) {
        adv_vie = max_vie;
    }
}

void adv_hit() {
    self_vie -= degats(adv_atk, self_def); // Attaque du joueur
}

void adv_boost_atk() {
    adv_atk = boost(adv_atk, 20); // Augmentation de l'attaque de l'adversaire
}

void adv_boost_def() {
    adv_def = boost(adv_def, 30); // Augmentation de la défense de l'adversaire
}

void adv_action(int id) {
    switch(id) {
        case 1: {
            printf("L'adversaire me cogne.\n");
            adv_hit();
            break;
        }
        case 2: {
            printf("L'adversaire se soigne.\n");
            adv_regen();
            break;
        }
        case 3: {
            printf("L'adversaire augmente son attaque.\n");
            adv_boost_atk();
            break;
        }
        case 4: {
            printf("L'adversaire augmente sa défense.\n");
            adv_boost_def();
            break;
        }
    }
}

/* Affichage du jeu */
void display_actions() {
    printf(" 1 - Cogner.\n"
           " 2 - Se soigner.\n"
           " 3 - Augmenter attaque.\n"
           " 4 - Augmenter défense.\n");
}

void display() {
    printf("+-------------------+-------------------+\n");
    printf("| Joueur    | Adversaire |\n");
    printf("+-------------------+-------------------+\n");
    printf("| Vie       | %11d | %11d |\n", self_vie, adv_vie);
    printf("| Attaque   | %11d | %11d |\n", self_atk, adv_atk);
    printf("| Défense   | %11d | %11d |\n", self_def, adv_def);
    printf("+-------------------+-------------------+\n");
}

/* Un combat */
int main() {
    int self_choix;
    int adv_choix;
    srand(time(NULL));
    init();
    while (self_vie > 0 && adv_vie > 0) {
        display();
        display_actions();
        printf("Votre choix : ");
        scanf("%d", &self_choix);
        adv_choix = 1;
        if (rand() % 2 == 0) {
            adv_choix = 2 + rand() % 3;
        }
        self_action(self_choix);
        adv_action(adv_choix);
    }
    if (self_vie <= 0 && adv_vie <= 0) {
        printf("Match nul.\n");
    } else if (self_vie > 0) {
        printf("Victoire !\n");
    } else {
        printf("Défaite !\n");
    }
    exit(EXIT_SUCCESS);
}