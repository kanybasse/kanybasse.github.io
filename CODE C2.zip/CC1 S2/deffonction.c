#include <stdio.h>
#include <stdlib.h>

// Définition de la fonction carre
int carre(int x) {
    // Calcul du carré de x
    return x * x;
}

// Fonction principale
int main() {
    // Déclaration et initialisation de la variable a
    int a = 41;
    
    // Affichage des calculs
    printf("(%d + 1) * (%d + 1) = %d\n", a, a, (a + 1) * (a + 1));
    printf("carre(%d + 1) = %d\n", a, carre(a + 1));
    
    // Vérification si les résultats sont égaux
    if ((a + 1) * (a + 1) == carre(a + 1)) {
        printf("Bravo !\n"); // Affichage d'un message si les résultats sont égaux
    }
    
    
    return 0;
}
