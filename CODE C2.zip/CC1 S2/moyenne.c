#include <stdio.h>
#include <stdlib.h>

/* Déclaration de la fonction moyenne */
float moyenne();

int main() {
    printf("La moyenne de ");
    printf("= %g\n", moyenne()); // Appel de la fonction moyenne
    exit(EXIT_SUCCESS);
}

/* Définition de la fonction moyenne */
float moyenne() {
    float val;
    int nb = 0;
    float sum = 0;

    /* Lecture des valeurs au clavier jusqu'à ce qu'une valeur négative soit entrée */
    for (;;) {
        scanf("%f", &val);
        if (val < 0) {
            break; // Sort de la boucle si la valeur est négative
        }
        sum += val; // Ajoute la valeur à la somme
        ++nb; // Incrémente le nombre de valeurs entrées
    }

    /* Calcul de la moyenne si au moins une valeur a été entrée */
    if (nb > 0) {
        sum /= nb;
    }

    return sum; // Retourne la moyenne calculée
}
