#include <stdio.h>
#include <math.h>
#include <time.h>

// Fonction pour calculer le sinus en utilisant le développement de Taylor jusqu'au degré 15
long double sinus_taylor(long double x) {
    long double result = 0.0;
    long double term = x;  // Le premier terme est x
    int n = 1;  // n représente le facteur (2k + 1) dans la série

    // Je boucle pour ajouter chaque terme de la série de Taylor jusqu'au degré 15
    for (int i = 1; i <= 15; i += 2) {
        result += term;
        term *= -x * x / ((n + 1) * (n + 2));
        n += 2;
    }

    return result;
}

// Fonction pour normaliser l'angle entre -pi et pi
long double normaliser_angle(long double x) {
    // Je réduis l'angle pour qu'il soit dans la plage [-pi, pi]
    x = fmod(x, 2.0 * M_PI);
    if (x > M_PI) {
        x -= 2.0 * M_PI;
    } else if (x < -M_PI) {
        x += 2.0 * M_PI;
    }
    return x;
}

// Fonction pour mesurer le temps d'exécution
double mesure_temps(clock_t start, clock_t end) {
    return ((double) (end - start)) / CLOCKS_PER_SEC;
}

// Fonction pour comparer les résultats du sinus de Taylor et du sinus natif
void comparaison_sinus(long double x) {
    clock_t start_time, end_time;
    long double result_taylor, result_cmath;
    double time_taylor, time_cmath;

    // Je normalise l'angle x
    long double x_normalized = normaliser_angle(x);

    // Je mesure le temps pour la méthode de Taylor
    start_time = clock();
    result_taylor = sinus_taylor(x_normalized);
    end_time = clock();
    time_taylor = mesure_temps(start_time, end_time);

    // Je mesure le temps pour la méthode native de sin
    start_time = clock();
    result_cmath = sin(x);
    end_time = clock();
    time_cmath = mesure_temps(start_time, end_time);

    // J'affiche les résultats et le temps d'exécution pour chaque méthode
    printf("sin(%.15Lf) = %.15Lf (en %f s) (rapide en 0)\n", x, result_taylor, time_taylor);
    printf("sin(%.15Lf) = %.15Lf (en %f s) (d'après math)\n", x, result_cmath, time_cmath);
}

// Fonction principale où je demande à l'utilisateur d'entrer un réel
int main() {
    long double x;

    // Je demande à l'utilisateur d'entrer un réel
    printf("Entrez un réel : ");
    scanf("%Lf", &x);

    // Je compare les résultats pour la valeur entrée
    comparaison_sinus(x);

    return 0;
}
