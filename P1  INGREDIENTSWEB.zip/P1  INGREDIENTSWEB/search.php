<?php
// Simulated database of recipes
$recipes = array(
    array(
        "name" => "Pasta Carbonara",
        "ingredients" => array("pasta", "bacon", "eggs", "parmesan cheese", "black pepper")
    ),
    array(
        "name" => "Caprese Salad",
        "ingredients" => array("tomatoes", "mozzarella cheese", "fresh basil", "balsamic vinegar", "olive oil")
    ),
    array(
        "name" => "Spaghetti Bolognese",
        "ingredients" => array("spaghetti", "ground beef", "tomato sauce", "onion", "garlic", "olive oil")
    ),
    array(
        "name" => "Chicken Alfredo",
        "ingredients" => array("chicken breast", "fettuccine pasta", "heavy cream", "butter", "parmesan cheese", "garlic")
    ),
    array(
        "name" => "Caesar Salad",
        "ingredients" => array("romaine lettuce", "croutons", "parmesan cheese", "caesar dressing")
    ),
    array(
        "name" => "Margherita Pizza",
        "ingredients" => array("pizza dough", "tomato sauce", "fresh mozzarella cheese", "fresh basil leaves", "olive oil")
    ),
    array(
        "name" => "Chicken Stir-Fry",
        "ingredients" => array("chicken breast", "bell peppers", "broccoli", "carrots", "soy sauce", "garlic", "ginger")
    ),
    array(
        "name" => "Vegetable Soup",
        "ingredients" => array("tomatoes", "vegetable broth", "carrots", "celery", "onion", "potatoes", "corn", "green beans", "peas")
    ),
    array(
        "name" => "Beef Tacos",
        "ingredients" => array("ground beef", "taco shells", "shredded lettuce", "diced tomatoes", "shredded cheese", "salsa")
    ),
    array(
        "name" => "Mushroom Risotto",
        "ingredients" => array("arborio rice", "mushrooms", "vegetable broth", "white wine", "onion", "parmesan cheese")
    ),
);

// Retrieve ingredients from the form
$ingredients = isset($_POST['ingredients']) ? explode(",", $_POST['ingredients']) : array();

// Find matching recipes
$matchingRecipes = array();
foreach ($recipes as $recipe) {
    $recipeIngredients = $recipe['ingredients'];
    if (count(array_intersect($ingredients, $recipeIngredients)) === count($ingredients)) {
        $matchingRecipes[] = $recipe;
    }
}

// Display matching recipes
if (empty($matchingRecipes)) {
    echo "<p>No recipes found for the provided ingredients.</p>";
} else {
    echo "<h2>Matching Recipes:</h2>";
    echo "<ul>";
    foreach ($matchingRecipes as $recipe) {
        echo "<li>{$recipe['name']}</li>";
    }
    echo "</ul>";
}


?>
